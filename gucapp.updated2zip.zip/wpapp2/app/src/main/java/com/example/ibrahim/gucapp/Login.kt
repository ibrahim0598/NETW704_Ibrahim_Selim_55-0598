package com.example.ibrahim.gucapp

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class Login : AppCompatActivity() {

    private lateinit var edtEmail: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnLogin: Button
    private lateinit var btnSignUp: Button
    private lateinit var mAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance()

        // Link UI elements to variables
        edtEmail = findViewById(R.id.edt_email)
        edtPassword = findViewById(R.id.edt_password)
        btnLogin = findViewById(R.id.btnLogin)
        btnSignUp = findViewById(R.id.btnSignUp)

        // Handle sign up button click
        btnSignUp.setOnClickListener {
            val intent = Intent(this, signup::class.java) // Corrected class name
            startActivity(intent)
        }

        // Handle login button click
        btnLogin.setOnClickListener {
            val email = edtEmail.text.toString()
            val password = edtPassword.text.toString()

            // Ensure fields are not empty before attempting login
            if (email.isNotEmpty() && password.isNotEmpty()) {
                login(email, password)
            } else {
                showError("Please fill in all fields")
            }
        }
    }

    // Function to handle user login with Firebase Authentication
    private fun login(email: String, password: String) {
        mAuth.signInWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Login successful, navigate to MainActivity
                    val intent = Intent(this@Login, SignInDetailsActivity::class.java)
                    startActivity(intent)
                    finish() // Optionally close the login activity after successful login
                } else {
                    // Login failed, display the specific error message
                    task.exception?.message?.let {
                        showError(it)
                    } ?: showError("Login failed, please try again")
                }
            }
    }

    // Function to show error messages via Toast
    private fun showError(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }
}
