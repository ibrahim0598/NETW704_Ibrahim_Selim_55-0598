package com.example.ibrahim.gucapp

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.Toast
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.UserProfileChangeRequest

class SignInDetailsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_sign_in_details)

        // Initialize FirebaseAuth
        val mAuth = FirebaseAuth.getInstance()

        // TextView to display user details
        val userDetailsTextView = findViewById<TextView>(R.id.user_details_text_view)
        val editDisplayName = findViewById<EditText>(R.id.edit_display_name)
        val btnUpdateDisplayName = findViewById<Button>(R.id.btn_update_display_name)
        val btnSignInDetails = findViewById<Button>(R.id.btn_sign_in_details)
        val btnMap = findViewById<Button>(R.id.btn_map) // Assuming you have a button for map

        // Sign In Details button functionality
        btnSignInDetails.setOnClickListener {
            // Open ProfileActivity when the button is clicked
            val intent = Intent(this, ProfileActivity::class.java)
            startActivity(intent)
        }

        // Update Display Name functionality
        btnUpdateDisplayName.setOnClickListener {
            val newDisplayName = editDisplayName.text.toString()
            if (newDisplayName.isNotEmpty()) {
                val user = mAuth.currentUser
                if (user != null) {
                    val profileUpdates = UserProfileChangeRequest.Builder()
                        .setDisplayName(newDisplayName)
                        .build()

                    user.updateProfile(profileUpdates)
                        .addOnCompleteListener { task ->
                            if (task.isSuccessful) {
                                userDetailsTextView.text = "Email: ${user.email}\nDisplay Name: $newDisplayName"
                                Toast.makeText(this, "Display name updated", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(this, "Failed to update display name", Toast.LENGTH_SHORT).show()
                            }
                        }
                }
            } else {
                Toast.makeText(this, "Please enter a display name", Toast.LENGTH_SHORT).show()
            }
        }

        // Map button functionality to open MapActivity
        btnMap.setOnClickListener {
            val mapIntent = Intent(this, MapActivity::class.java)
            startActivity(mapIntent)
        }
    }
}
