package com.example.ibrahim.gucapp

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.widget.Button

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Sign In button click listener
        val btnSignIn = findViewById<Button>(R.id.btn_sign_in)
        btnSignIn.setOnClickListener {
            // Navigate to SignInDetailsActivity
            val intent = Intent(this, Login::class.java)
            startActivity(intent)
        }

        // Sign Up button (This can be further handled as needed)
        val btnSignUp = findViewById<Button>(R.id.btn_sign_up)
        btnSignUp.setOnClickListener {
            // Navigate to Signup activity
            val intent = Intent(this, signup::class.java)
            startActivity(intent)
        }

    }
}
